import json
from lambda_chatbot import lambda_handler

# Simulate an event object
event = {
    'body': json.dumps({
        'messages': [
            {'role': 'user', 'content': 'Hi, I need help with my rental agreement'}
        ]
    })
}

# Simulate an empty context object (not used in this example)
context = {}

if __name__ == "__main__":
    response = lambda_handler(event, context)
    print("Lambda function response:")
    print(response)
